#pragma once
#include <stdio.h>
#include <stdlib.h>

#include "ListOperations.h"
#include "Drawing.h"
#include "UserFunctions.h"
#include "NetworkCommands.h"
#include "UserMenu.h"
